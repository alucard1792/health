define( function() {
	return window.location;
} );
